WEMBUX SERVER HOST - START HERE

1. Extract this ZIP on the laptop that will host the server. Do not run the BAT from inside the ZIP preview.
2. The laptop needs Windows, Python 3.11 or newer, and an internet connection.
3. Double-click Start-Wembux-Server.bat in the extracted folder.
4. On first run, choose the owner username and password when prompted.
5. Keep the server window open. When the temporary HTTPS link appears, share it with the people who will use Wembux.
6. To stop the server and tunnel, press Ctrl+C in the server window.

The BAT creates its Python environment and installs the required Python package. It also tries to install Cloudflare Tunnel with winget.
Server data is saved on the host laptop under %LOCALAPPDATA%\Wembux\data.
