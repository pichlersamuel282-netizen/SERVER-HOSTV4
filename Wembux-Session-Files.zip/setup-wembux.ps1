$ErrorActionPreference = 'Stop'

$installDirectory = Join-Path $env:LOCALAPPDATA 'Wembux'
New-Item -ItemType Directory -Path $installDirectory -Force | Out-Null
foreach ($fileName in @(
    'index.html', 'login.html', 'account-admin.html', 'wembux-users.js',
    'manifest.webmanifest', 'build-info.json', 'wembux.ico', 'wembux-192.png', 'wembux-512.png',
    'wembux-power.ps1', 'wembux_host.py', 'wembux_server.py', 'wembux-launcher.cmd', 'requirements.txt',
    'Start-Wembux-Server.bat', 'Wembux-Status.bat'
)) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $fileName) -Destination (Join-Path $installDirectory $fileName) -Force
}

$powerShellPath = Join-Path $PSHOME 'powershell.exe'
$handlerPath = Join-Path $installDirectory 'wembux-power.ps1'
$protocolKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Classes\wembux')
$protocolKey.SetValue('', 'URL:Wembux Protocol')
$protocolKey.SetValue('URL Protocol', '')
$protocolKey.Dispose()

$commandKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Classes\wembux\shell\open\command')
$commandKey.SetValue('', "`"$powerShellPath`" -NoProfile -ExecutionPolicy Bypass -File `"$handlerPath`" `"%1`"")
$commandKey.Dispose()

$desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
$shortcutPath = Join-Path $desktop 'Wembux.lnk'
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$launcherPath = Join-Path $installDirectory 'wembux-launcher.cmd'
$shortcut.TargetPath = $env:ComSpec
$shortcut.Arguments = "/c `"`"$launcherPath`"`""
$shortcut.WorkingDirectory = $installDirectory
$shortcut.IconLocation = (Join-Path $installDirectory 'wembux.ico') + ',0'
$shortcut.Description = 'Open Wembux chat app'
$shortcut.Save()

$serverBatPath = Join-Path $installDirectory 'Start-Wembux-Server.bat'
$serverShortcut = $shell.CreateShortcut((Join-Path $desktop 'Start Wembux Server.lnk'))
$serverShortcut.TargetPath = $env:ComSpec
$serverShortcut.Arguments = "/c `"`"$serverBatPath`"`""
$serverShortcut.WorkingDirectory = $installDirectory
$serverShortcut.IconLocation = (Join-Path $installDirectory 'wembux.ico') + ',0'
$serverShortcut.Description = 'Start the Wembux chat server for other users'
$serverShortcut.Save()

Start-Process -FilePath $env:ComSpec -ArgumentList "/c `"`"$launcherPath`"`"" -WorkingDirectory $installDirectory
