$ErrorActionPreference = 'Stop'

$workspace = $PSScriptRoot
$archivePath = Join-Path $workspace 'Wembux-Server-Host-Portable.zip'
$outputPath = Join-Path $workspace 'Wembux-Server-Host-Single-File.bat'
if (-not (Test-Path -LiteralPath $archivePath)) {
    throw 'Build Wembux-Server-Host-Portable.zip first.'
}

$payload = [Convert]::ToBase64String([IO.File]::ReadAllBytes($archivePath))
$payloadLines = [regex]::Matches($payload, '.{1,76}') | ForEach-Object { $_.Value }
$prefix = @'
@echo off
setlocal EnableExtensions
set "WEMBUX_INSTALL_DIR=%LOCALAPPDATA%\Wembux-Server-Host"
set "WEMBUX_SELF=%~f0"
echo Extracting the Wembux server files...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=[IO.File]::ReadAllText($env:WEMBUX_SELF);$m=':WEMBUX_PAYLOAD:';$i=$p.LastIndexOf($m);if($i -lt 0){exit 2};$b=$p.Substring($i+$m.Length)-replace '\s','';$z=Join-Path $env:TEMP ('wembux-host-'+[guid]::NewGuid().ToString('N')+'.zip');[IO.File]::WriteAllBytes($z,[Convert]::FromBase64String($b));Expand-Archive -LiteralPath $z -DestinationPath $env:WEMBUX_INSTALL_DIR -Force;Remove-Item -LiteralPath $z -Force"
if errorlevel 1 (
  echo Could not extract the Wembux server files.
  pause
  exit /b 1
)
call "%WEMBUX_INSTALL_DIR%\Start-Wembux-Server.bat"
set "HOST_EXIT=%ERRORLEVEL%"
if not "%HOST_EXIT%"=="0" (
  echo Wembux server exited with error code %HOST_EXIT%.
  pause
)
exit /b %HOST_EXIT%
:WEMBUX_PAYLOAD:
'@
[IO.File]::WriteAllText($outputPath, $prefix + ($payloadLines -join "`r`n") + "`r`n", [Text.Encoding]::ASCII)
Get-Item $outputPath | Select-Object FullName, Length
