@echo off
setlocal
set "APP_URL=http://127.0.0.1:8765/"
curl.exe -fsS "http://127.0.0.1:8765/api/health" >nul 2>nul
if errorlevel 1 (
    echo Wembux server is not running. Run Start-Wembux-Server.bat first.
    pause
    exit /b 1
)
for %%I in ("%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe") do if exist "%%~I" (
  start "" "%%~I" --new-window --app="%APP_URL%" --disable-features=Translate --disable-background-networking
  exit /b 0
)
echo Wembux needs Microsoft Edge or Google Chrome to open its app window.
pause
exit /b 1
