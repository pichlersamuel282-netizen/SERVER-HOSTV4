$ErrorActionPreference = 'Stop'

$workspace = $PSScriptRoot
$files = @(
    'index.html', 'login.html', 'account-admin.html', 'wembux-users.js',
    'manifest.webmanifest', 'build-info.json', 'wembux.ico', 'wembux-192.png', 'wembux-512.png',
    'wembux-power.ps1', 'wembux_host.py', 'wembux_server.py', 'wembux-launcher.cmd', 'requirements.txt',
    'Start-Wembux-Server.bat', 'Wembux-Status.bat', 'setup-wembux.ps1'
)
foreach ($fileName in $files) {
    if (-not (Test-Path (Join-Path $workspace $fileName))) {
        throw "Required package file not found: $fileName"
    }
}

$outputPath = Join-Path $workspace 'Wembux-Download.exe'
$sedPath = Join-Path $env:TEMP 'Wembux-IExpress.sed'
$sourceEntries = for ($index = 0; $index -lt $files.Count; $index++) {
    "FILE$index=`"$($files[$index])`""
}
$fileEntries = for ($index = 0; $index -lt $files.Count; $index++) {
    "%FILE$index%="
}
$sed = @(
    '[Version]'
    'Class=IEXPRESS'
    'SEDVersion=3'
    '[Options]'
    'PackagePurpose=InstallApp'
    'ShowInstallProgramWindow=0'
    'HideExtractAnimation=1'
    'UseLongFileName=1'
    'InsideCompressed=0'
    'CAB_FixedSize=0'
    'CAB_ResvCodeSigning=0'
    'RebootMode=N'
    'InstallPrompt='
    'DisplayLicense='
    'FinishMessage='
    "TargetName=`"$outputPath`""
    'FriendlyName=Wembux'
    'AppLaunched=powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File setup-wembux.ps1'
    'PostInstallCmd=<None>'
    'AdminQuietInstCmd='
    'UserQuietInstCmd='
    'SourceFiles=SourceFiles'
    '[SourceFiles]'
    "SourceFiles0=`"$workspace`""
    '[SourceFiles0]'
) + $fileEntries + @('[Strings]') + $sourceEntries

[System.IO.File]::WriteAllLines($sedPath, $sed, [System.Text.Encoding]::Default)
$iexpressPath = Join-Path $env:WINDIR 'System32\iexpress.exe'
& $iexpressPath /N $sedPath
if (-not (Test-Path $outputPath)) {
    throw 'IExpress could not build the Wembux download package.'
}

Get-Item $outputPath | Select-Object FullName, Length
