param(
    [Parameter(Mandatory = $true)]
    [string]$ActionUrl
)

$ErrorActionPreference = 'Stop'
$shell = New-Object -ComObject WScript.Shell

function Select-UsbDisk {
    $usbDisks = @(Get-Disk | Where-Object {
        $_.BusType -eq 'USB' -and -not $_.IsBoot -and -not $_.IsSystem
    })
    if ($usbDisks.Count -eq 0) {
        throw 'No USB drives were found. Connect a USB drive and try again.'
    }

    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Choose a USB drive'
    $form.Width = 560
    $form.Height = 270
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false

    $list = New-Object System.Windows.Forms.ListBox
    $list.Left = 12
    $list.Top = 12
    $list.Width = 520
    $list.Height = 170
    foreach ($disk in $usbDisks) {
        $label = 'Disk {0} | {1} | {2:N1} GB | S/N: {3}' -f $disk.Number, $disk.FriendlyName, ($disk.Size / 1GB), $disk.SerialNumber
        [void]$list.Items.Add($label)
    }
    $form.Controls.Add($list)

    $selectButton = New-Object System.Windows.Forms.Button
    $selectButton.Text = 'Select drive'
    $selectButton.Left = 350
    $selectButton.Top = 190
    $selectButton.Width = 90
    $selectButton.Add_Click({
        if ($list.SelectedIndex -ge 0) {
            $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $form.Close()
        }
    })
    $form.Controls.Add($selectButton)
    $form.AcceptButton = $selectButton

    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Text = 'Cancel'
    $cancelButton.Left = 442
    $cancelButton.Top = 190
    $cancelButton.Width = 90
    $cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.Controls.Add($cancelButton)
    $form.CancelButton = $cancelButton

    $result = $form.ShowDialog()
    $selectedIndex = $list.SelectedIndex
    $form.Dispose()
    if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }
    return $usbDisks[$selectedIndex]
}

function Get-UsbDriveLetters([int]$DiskNumber) {
    return @(Get-Partition -DiskNumber $DiskNumber | Where-Object {
        $_.DriveLetter
    } | ForEach-Object { "$($_.DriveLetter):\" })
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

try {
    $action = [Uri]$ActionUrl
    if ($action.Scheme -ne 'wembux' -or $action.Host -notin @('power', 'bios', 'usb')) {
        throw 'Unsupported Wembux action.'
    }

    $item = $action.AbsolutePath.Trim('/').ToLowerInvariant()
    if ($action.Host -eq 'usb') {
        if ($item -notin @('scan', 'junk', 'erase')) {
            throw 'That Wembux USB action is not supported.'
        }

        if (-not (Test-Administrator)) {
            $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -ActionUrl `"$ActionUrl`""
            Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $arguments
            exit 0
        }

        $disk = Select-UsbDisk
        if (-not $disk) {
            exit 0
        }
        $driveLetters = @(Get-UsbDriveLetters -DiskNumber $disk.Number)
        if ($item -ne 'erase' -and $driveLetters.Count -eq 0) {
            throw 'The selected USB drive has no mounted drive letter. Assign one in Disk Management and try again.'
        }

        if ($item -eq 'scan') {
            foreach ($drive in $driveLetters) {
                Start-MpScan -ScanType CustomScan -ScanPath $drive
            }
            $message = "Microsoft Defender was asked to scan the selected USB drive ($($driveLetters -join ', ')). Detected threats are handled using your Defender protection settings."
            $title = 'Wembux USB malware scan'
            $icon = 64
        }
        elseif ($item -eq 'junk') {
            $junkFiles = @(
                foreach ($drive in $driveLetters) {
                    Get-ChildItem -LiteralPath $drive -File -Force -Recurse -ErrorAction SilentlyContinue | Where-Object {
                        ($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq 0 -and
                        $_.Name -match '^(Thumbs\.db|\.DS_Store|desktop\.ini|\._.+|~\$.*|.+\.tmp)$'
                    }
                }
            )
            if ($junkFiles.Count -eq 0) {
                $message = 'No known junk files were found on the selected USB drive.'
            }
            else {
                $examples = ($junkFiles | Select-Object -First 8 | ForEach-Object { $_.FullName }) -join "`r`n"
                $answer = $shell.Popup("Remove $($junkFiles.Count) known junk files?`r`n`r`nOnly temporary files and common OS metadata are included. Personal documents are not selected.`r`n`r`n$examples", 0, 'Confirm USB junk cleanup', 33)
                if ($answer -ne 1) {
                    exit 0
                }
                foreach ($file in $junkFiles) {
                    Remove-Item -LiteralPath $file.FullName -Force
                }
                $message = "Removed $($junkFiles.Count) known junk files from the selected USB drive."
            }
            $title = 'Wembux USB cleanup'
            $icon = 64
        }
        else {
            $disk = Get-Disk -Number $disk.Number
            if ($disk.BusType -ne 'USB' -or $disk.IsBoot -or $disk.IsSystem) {
                throw 'The selected device no longer appears to be a non-system USB drive. Nothing was erased.'
            }
            $details = "Disk $($disk.Number) | $($disk.FriendlyName) | $([math]::Round($disk.Size / 1GB, 1)) GB | S/N: $($disk.SerialNumber)"
            $answer = $shell.Popup("ERASE EVERYTHING on this USB drive, including all partitions and files?`r`n`r`n$details`r`n`r`nThis cannot be undone. The drive will be reformatted as exFAT.", 0, 'Erase entire USB drive', 49)
            if ($answer -ne 1) {
                exit 0
            }
            Add-Type -AssemblyName Microsoft.VisualBasic
            $confirmation = [Microsoft.VisualBasic.Interaction]::InputBox("Type ERASE to permanently erase this entire USB drive:`r`n`r`n$details", 'Final USB erase confirmation', '')
            if ($confirmation -cne 'ERASE') {
                throw 'USB erase canceled. The drive was not changed.'
            }

            Set-Disk -Number $disk.Number -IsOffline $false
            Set-Disk -Number $disk.Number -IsReadOnly $false
            Clear-Disk -Number $disk.Number -RemoveData -RemoveOEM -Confirm:$false
            $partitionStyle = if ($disk.Size -gt 2TB) { 'GPT' } else { 'MBR' }
            Initialize-Disk -Number $disk.Number -PartitionStyle $partitionStyle
            $partition = New-Partition -DiskNumber $disk.Number -UseMaximumSize -AssignDriveLetter
            Format-Volume -Partition $partition -FileSystem exFAT -NewFileSystemLabel 'WEMBUX' -Confirm:$false -Force | Out-Null
            $message = "The entire USB drive was erased and formatted as exFAT. New drive letter: $($partition.DriveLetter):"
            $title = 'Wembux USB erase complete'
            $icon = 64
        }
    }
    elseif ($action.Host -eq 'power') {
        $plans = @{
            balanced = @{ Guid = '381b4222-f694-41f0-9685-ff5bb260df2e'; Name = 'Balanced' }
            performance = @{ Guid = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'; Name = 'High performance' }
            quiet = @{ Guid = 'a1841308-3541-4fab-bc81-f71556f20b4a'; Name = 'Power saver' }
        }

        if (-not $plans.ContainsKey($item)) {
            throw 'That Wembux power profile is not supported.'
        }

        $selectedPlan = $plans[$item]
        & powercfg.exe /setactive $selectedPlan.Guid
        if ($LASTEXITCODE -ne 0) {
            throw 'Windows could not activate that power plan.'
        }

        $message = "Wembux applied the $($selectedPlan.Name) Windows power plan. You can change it any time in Windows Settings."
        $title = 'Wembux power profile'
        $icon = 64
    }
    elseif ($item -eq 'cancel') {
        & shutdown.exe /a 2>$null
        if ($LASTEXITCODE -ne 0) {
            throw 'There is no pending restart to cancel.'
        }

        $message = 'The pending Wembux restart was canceled.'
        $title = 'Wembux BIOS activation'
        $icon = 64
    }
    else {
        $topics = @{
            memory = @{ Name = 'Memory profile (A-XMP)'; Menu = 'MSI Click BIOS: OC > A-XMP' }
            boot = @{ Name = 'Boot order'; Menu = 'MSI Click BIOS: Settings > Boot' }
            virtualization = @{ Name = 'CPU virtualization (SVM)'; Menu = 'MSI Click BIOS: OC or Settings > Advanced > CPU Configuration > SVM Mode' }
            security = @{ Name = 'Secure Boot / TPM'; Menu = 'MSI Click BIOS: Settings > Security or Trusted Computing' }
            fans = @{ Name = 'Fan curves'; Menu = 'MSI Click BIOS: Hardware Monitor' }
        }

        if ($action.Host -ne 'bios' -or -not $topics.ContainsKey($item)) {
            throw 'That Wembux BIOS topic is not supported.'
        }

        $topic = $topics[$item]
        $answer = $shell.Popup("Restart Windows into UEFI now to work on: $($topic.Name)?`r`n`r`nSave your files first. Wembux will schedule the restart in 60 seconds; cancel it from the BIOS Activate page if needed.`r`n`r`nWembux does not change BIOS values.", 0, 'Confirm BIOS activation', 33)
        if ($answer -ne 1) {
            exit 0
        }

        & shutdown.exe /r /fw /t 60 /c "Wembux: open UEFI for $($topic.Name). Cancel from BIOS Activate in Wembux if needed."
        if ($LASTEXITCODE -ne 0) {
            throw 'Windows could not schedule a firmware restart. Use Windows Advanced startup or restart and press the MSI BIOS key.'
        }

        $message = "Restart scheduled in 60 seconds for $($topic.Name).`r`n`r`nAfter the reboot, look for: $($topic.Menu).`r`n`r`nWembux does not set the value. Cancel from BIOS Activate if you are not ready."
        $title = 'Wembux BIOS activation'
        $icon = 64
    }
}
catch {
    $message = "Wembux could not complete that action.`r`n`r`n$($_.Exception.Message)"
    $title = 'Wembux action'
    $icon = 16
}

$null = $shell.Popup($message, 8, $title, $icon)