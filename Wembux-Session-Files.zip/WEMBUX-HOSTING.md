# Host Wembux

## Start the server

1. Send `Wembux-Server-Host-Portable.zip` to the laptop that will host Wembux and extract it to a folder.
2. Run `Start-Wembux-Server.bat` from the extracted folder. The laptop needs Windows, Python 3.11 or newer, and an internet connection. The BAT prepares its Python environment and installs Cloudflare Tunnel with `winget` if needed.
3. On first start, enter the owner username (default `FRIGSS_FINDER`) and choose a password. This creates the server-side owner account; browser-local accounts are not imported.
4. When the tunnel is ready, the console prints a temporary `https://...trycloudflare.com` link. Share that link with users so they can register and chat from their own devices.

The host laptop must stay awake and online. The temporary link changes when the tunnel restarts. For a stable address, configure a named Cloudflare Tunnel and your own domain. `Wembux-Status.bat` opens the local server status and account dashboard while the server is running.

## Data and security

SQLite data is stored in `%LOCALAPPDATA%\Wembux\data\wembux.sqlite3`. Stop the server before backing up that file. Passwords are stored as scrypt hashes and browser sessions use HTTP-only cookies. HTTPS protects traffic through the tunnel, but chat messages are not end-to-end encrypted and are stored on the host laptop. Do not use this prototype for sensitive conversations.

The laptop must remain online for friends to sign in and exchange messages. Press Ctrl+C in the server window to stop the service and tunnel.
